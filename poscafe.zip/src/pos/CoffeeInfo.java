package pos;

public class CoffeeInfo {
	String name;
	int price;
	int num;
	int row;
	
	public CoffeeInfo(String name, int price) {
		super();
		this.name = name;
		this.price = price;
	}

	
}