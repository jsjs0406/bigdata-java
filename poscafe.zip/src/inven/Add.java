package inven;

public class Add {
	
	public static void main(String[] args) {
		Add add = new Add();
	}
}
