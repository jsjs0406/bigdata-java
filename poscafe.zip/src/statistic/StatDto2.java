package statistic;

public class StatDto2 {
	
	private int espressosaled;
	private int espressosalequand;
	private int americanosaled;
	private int americanosalequand;
	private int caffelattesaled;
	private int caffelattesalequand;
	private int viennacoffeesaled;
	private int viennacoffeesalequand;
	private int chocofrappuccinosaled;
	private int chocofrappuccinosalequand;
	private int quantity;
	private int tot_price;
	
	public StatDto2() {
		
	}
	
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getTot_price() {
		return tot_price;
	}

	public void setTot_price(int tot_price) {
		this.tot_price = tot_price;
	}

	
	public int getEspressosaled() {
		return espressosaled;
	}
	public void setEspressosaled(int espressosaled) {
		this.espressosaled = espressosaled;
	}
	public int getEspressosalequand() {
		return espressosalequand;
	}
	public void setEspressosalequand(int espressosalequand) {
		this.espressosalequand = espressosalequand;
	}
	public int getAmericanosaled() {
		return americanosaled;
	}
	public void setAmericanosaled(int americanosaled) {
		this.americanosaled = americanosaled;
	}
	public int getAmericanosalequand() {
		return americanosalequand;
	}
	public void setAmericanosalequand(int americanosalequand) {
		this.americanosalequand = americanosalequand;
	}
	public int getCaffelattesaled() {
		return caffelattesaled;
	}
	public void setCaffelattesaled(int caffelattesaled) {
		this.caffelattesaled = caffelattesaled;
	}
	public int getCaffelattesalequand() {
		return caffelattesalequand;
	}
	public void setCaffelattesalequand(int caffelattesalequand) {
		this.caffelattesalequand = caffelattesalequand;
	}
	public int getViennacoffeesaled() {
		return viennacoffeesaled;
	}
	public void setViennacoffeesaled(int viennacoffeesaled) {
		this.viennacoffeesaled = viennacoffeesaled;
	}
	public int getViennacoffeesalequand() {
		return viennacoffeesalequand;
	}
	public void setViennacoffeesalequand(int viennacoffeesalequand) {
		this.viennacoffeesalequand = viennacoffeesalequand;
	}
	public int getChocofrappuccinosaled() {
		return chocofrappuccinosaled;
	}
	public void setChocofrappuccinosaled(int chocofrappuccinosaled) {
		this.chocofrappuccinosaled = chocofrappuccinosaled;
	}
	public int getChocofrappuccinosalequand() {
		return chocofrappuccinosalequand;
	}
	public void setChocofrappuccinosalequand(int chocofrappuccinosalequand) {
		this.chocofrappuccinosalequand = chocofrappuccinosalequand;
	}

}