package java09;

public class 별 {

	public static void main(String[] args) {
		// 열줄프린트
		for (int i = 0; i < 10; i++) {
			// 1줄
			for (int j = 0; j < 10; j++) {
				System.out.print("★");
			}
			System.out.println();
		}

	}// m

}// c
