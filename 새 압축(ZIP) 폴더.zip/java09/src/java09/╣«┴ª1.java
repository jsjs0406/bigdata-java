package java09;

public class 문제1 {

	public static void main(String[] args) {
		int[][] num = { { 44, 55, 66 }, { 77, 88, 99, 100 } };
		int sum = 0;
		for (int i = 0; i < num.length; i++) {//length는 행을 나타냄 행계산 
			for (int j = 0; j < num[i].length; j++) {//열계산 열을 계산해주고 싶으면 이렇게
				sum = sum+num[i][j];
		}
			
		System.out.println(sum/num[i].length);
		sum=0;
			}
	}// m

}// m
