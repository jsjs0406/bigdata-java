package java06;

public class 문제1 {

	public static void main(String[] args) {
		double[] eye= {2.0, 1.5, 1, 1.2, 0.7};
		String[] fn= {"안영일","김애경","안근영","양정은"};
		
		for (double e : eye) {
			System.out.println(e);
		}
		for (String
		System.out.println(s[1]);
		System.out.println(s[0]);
		System.out.println(s[2]);
		
	}//m

}//c
