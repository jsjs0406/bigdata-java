package java06;

public class 배열연습2 {

	public static void main(String[] args) {
		int[] s= new int [5];
		s[0]=10;
		s[3]=30;
		s[1]=10;
		
		System.out.println(s[1]);
		System.out.println(s[0]);
		System.out.println(s[2]);

	}

}
