package 일기장;

import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Login {
	private static JTextField textField;
	private static JTextField textField_1;

	public static void main(String[] args) {
		JFrame f = new JFrame("나의 일기장 로그인 화면");
		f.setSize(500, 500);
		JLabel l = new JLabel();
		ImageIcon icon = new ImageIcon("diary.jpg");
		l.setIcon(icon);

		FlowLayout flow = new FlowLayout();
		f.getContentPane().setLayout(flow);

		JLabel lblNewLabel_1 = new JLabel("ID 입력:");
		f.getContentPane().add(lblNewLabel_1);

		textField = new JTextField();
		f.getContentPane().add(textField);
		textField.setColumns(10);

		JLabel lblNewLabel = new JLabel("PW입력:");
		f.getContentPane().add(lblNewLabel);

		textField_1 = new JTextField();
		f.getContentPane().add(textField_1);
		textField_1.setColumns(10);

		JButton btnNewButton = new JButton("로그인 처리");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = "root";
				String pw = "1234";
				if (id.equals(textField.getText()) && pw.equals(textField_1.getText())) {
					JOptionPane.showMessageDialog(null, "로그인 성공");
					다이어리 diary = new 다이어리();

				} else {
					JOptionPane.showMessageDialog(null, "아이디 또는 비밀번호가 틀렸습니다.");
				}
			}
		});
		btnNewButton.setBackground(Color.PINK);
		btnNewButton.setForeground(Color.RED);
		f.getContentPane().add(btnNewButton);
		f.getContentPane().add(l);

		f.setVisible(true);
	}

	public Login() {
		Login log = new Login();

	}// m

}// c
