package 생성자;

import java.util.Scanner;

public class BankBook {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Bank[] b1 = new Bank[3];
		String product, name = null;
		int money = 0;
		
		for (int i = 0; i < b1.length; i++) {
			System.out.print("상품명:");
			product = sc.next();
			System.out.print("예금주:");
			name = sc.next();
			System.out.print("예금액:");
			money = sc.nextInt();
			b1[i] = new Bank(product,name,money);
		}
		System.out.println("--------------------------");
		System.out.println(product+"통장에는"+money+"만원이 들어있어요.");
		System.out.println(name+"통장에는"+money+"만원이 들어있어요.");
		
		
	}//m

}//c
