package 생성자;

/**
 * @author user
 *
 */
public class Car {

		//정적속성//글로벌변수
		String color;
		boolean convertible;
		

		//생성자(보통 멤버변수 밑에다 만듦)
		public Car() {
			System.out.println("객체생성시 초기화할 처리를 실행...");
			
		}//오버로딩
		
		public Car(String color) {
			this.color = color;
		}
		
		public Car(String color,boolean convertible) //지역변수로 취급, 밖에 없는 변수로 취급함.(생성자 변수는 가독성을 위해 헷갈림을 방지하기 위해 )
		{
			//Color = color (앞에가 글로벌 변수, 이러면 가독성이 떨어지기때문에)
			this.color = color;//이렇게 해야함
			this.convertible =convertible;
		}
		
		
		
		//동적속성
		public void change() {
			System.out.println("기어를 바꾸다.");
		}
		public int speedUp(int nowSpeed) {
			return nowSpeed + 30;
		}
		
		@Override
		public String toString() {
			return "Car [color=" + color + ", convertible=" + convertible + "]";
		}
		

}//c
