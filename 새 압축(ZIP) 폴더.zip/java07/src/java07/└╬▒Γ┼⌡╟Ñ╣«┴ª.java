package java07;

import java.util.Scanner;

public class 인기투표문제 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String sing[] = new String[3];

		for (int i = 0; i < sing.length; i++) {
			System.out.print("가수 이름을 입력:");
			sing[i] = sc.next();

		}

		for (int i = 0; i < 3; i++) {
			if (i > 0) {
				System.out.print(",");
			}
			System.out.print(sing[i]);
		}
		int num = 0;
		int a = 0;
		int b = 0;
		int c = 0;

		while (true) {
			for (int i = 0; i < sing.length; i++) {
				System.out.println((i + 1) + sing[i] + " ");
			}
			System.out.println("투표번호>>");
			num = sc.nextInt();

			if (num == 1) {
				a++;
			} else if (num == 2) {
				b++;
			} else if (num == 3) {
				c++;
			} else {
				System.out.println("종료");
				break;
			}

		}
		for (int i = 0; i < sing.length; i++) {
			System.out.println((i + 1) + ")" + sing[i] + "  ");
			if (i == 0) {
				System.out.println(a + "표");
			}
			if (i == 1) {
				System.out.println(a + "표");
			}
			if (i == 2) {
				System.out.println(a + "표");
			}
		}

	}// m

}// c
