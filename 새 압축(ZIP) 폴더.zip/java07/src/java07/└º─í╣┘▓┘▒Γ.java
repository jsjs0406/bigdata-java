package java07;

public class 위치바꾸기 {

	public static void main(String[] args) {
		//66,99위치 바꾸기
		int[]num= {66,77,88,99};
		int imsi = num[0];//66을 넣어둔 상태
		num[0] = num[3];
		num[3] = imsi;
		for (int i : num) {
			System.out.println(i);
			
		}
	}

}
