package java07;

import java.util.Scanner;

public class 문제2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int[] num = new int [3];
		for (int i = 0; i < num.length; i++) {
			System.out.println("숫자를 입력하시오");
			num[i] = sc.nextInt();
			
			}
		System.out.println(num[0]+"+"+num[2]+"은="+(num[0]+num[2])+"입니다.");

	}// m

}// c
