package java07;

import java.util.Scanner;

public class 문제1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String[] num = new String [3];
		for (int i = 0; i < num.length; i++) {
			System.out.println("언어를 입력하시오");
			num[i] = sc.next();
		}
		System.out.println(num[0] + "보다는" + num[2]);
	}

}
