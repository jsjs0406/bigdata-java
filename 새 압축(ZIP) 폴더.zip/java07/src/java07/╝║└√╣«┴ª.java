package java07;

import java.util.Scanner;

public class 성적문제 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String[] name = new String[3];
		int[] java = new int[3];
		int[] spring = new int [3];
		
		for (int i = 0; i < spring.length; i++) {
			System.out.print("학생이름: ");
			name[i] = sc.next();
			System.out.print("학생 점수(자바) : ");
  			java[i] = sc.nextInt();
			System.out.print("학생 점수(스프링) : ");
			spring[i] = sc.nextInt();
		}
		System.out.println("학생 점수 중 제일 높은 자바 점수는?");
		int max = java[0];
		int rank = 0;
		for (int i = 0; i < spring.length; i++) {
			if(max < java[i]) {
				max = java[i];
				rank=i;
			}
		}
		System.out.println(max + " " + "(" + name[rank] + ")");
		
		System.out.println("학생 점수 중 제일 낮은 스프링 점수는?");
		int min = spring[0];
		int rank1 = 0;
		for (int i = 0; i < spring.length; i++) {
			if(min > spring[i]) {
				min = spring[i];
				rank1=i;
				 System.out.println("*****" + rank1);
			}
		}
		System.out.println(min + " " + "(" + name[rank1] + ")");

	}//m

}//c
