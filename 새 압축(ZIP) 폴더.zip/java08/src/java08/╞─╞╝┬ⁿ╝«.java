package java08;

import java.util.Scanner;

public class 파티참석 {

	public static void main(String[] args) {
		System.out.println("이름과 나이를 입력하세요.");
		Scanner sc = new Scanner(System.in);
		String[] name = new String[5];
		int[] age = new int[5];
		double result = 0;
		
		for (int i = 0; i < age.length; i++) {
			System.out.print("입력 >>>>>");
			name[i] = sc.next();
			age[i] = sc.nextInt();
			
		}
		System.out.println("총인원:"+name.length);
		System.out.println("파티 참석자 전체 명단입니다.");
		
		for (int i = 0; i < age.length; i++) {
			System.out.println("이름은:"+name[i]+",나이는:"+age[i]);
			result  =result +age[i];
		}
		System.out.println("파티 참석자 나이의 평균은:"+(result/5));

	
	
	
	
	}//m
	
	
}//c
