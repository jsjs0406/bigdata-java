package java10;

public class 클래스부품만들기 {// phone

		// ex>전화기==> class
		// -특징, 특성을 찾아서 부품을 만들어야 함,(attribute, property)
		// 모양, 크기, 제조회사(정적특성)==>멤버변수
		String shape;
		int size;
		String company;
		
		// 전화하다, 문자보내다, 알람을 맞추다,(동적특성) ==>멤버 메소드
		public String call() {//누구랑 통화 했는지(처리결과) 반환값을 넣어줌
			return "친구"; 
		}
		public void text() {
			System.out.println("문자하다.");//반환값이 없는상태 그래서 void사용함
			
		}
		public int alarm() {
			System.out.println("알람을 맞추다.");
			return 11;
		}
		
		
		
		@Override
		public String toString() {
			return "클래스부품만들기 [shape=" + shape + ", size=" + size + ", company=" + company + "]";
		}//반환값(return)이 있으니 해당타입인 스트링 사용함
		
		
		
		
	

}//c
