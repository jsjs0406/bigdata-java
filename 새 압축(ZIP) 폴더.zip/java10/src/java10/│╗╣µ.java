package java10;

public class 내방 {

	public static void main(String[] args) {
		클래스부품만들기 p1 =new 클래스부품만들기();
		p1.company = "apple";
		p1.shape = "네모모양";
		p1.size = 11;
		
		System.out.println(p1.company);
		System.out.println(p1.shape);
		System.out.println(p1.size);
		
		p1.call();
		p1.text();
		p1.alarm();
		
		클래스부품만들기 p2 =new 클래스부품만들기();
		p2.company = "samsung";
		p2.shape ="네모모양";
		p1.size = 12;
		
		p2.call();
		p2.text();
		p2.alarm();
		
		//생성자를 이용하면 밑에 컬러, 파워, 사이즈 없앨수 있음
		부품tv만들기 tv1 = new 부품tv만들기();
		tv1.color = "검정색";
		tv1.power = true;
		tv1.size = 50;
		//System.out.println(tv1.color);
		//System.out.println(tv1.power);
		//System.out.println(tv1.size);
		System.out.println(tv1);
		
		tv1.changech();
		tv1.connect();
		tv1.sound();
		System.out.println();
		
		//class를 복사해서 만든  tv2를 객채(대상, object)
		//new의 역할 : 객채 생성
		부품tv만들기 tv2 = new 부품tv만들기();
		tv2.color ="빨강색";
		tv2.power = false;
		tv2.size = 30;
		//System.out.println(tv2.color);
		//System.out.println(tv2.power);
		//System.out.println(tv2.size);
		
		System.out.println(tv2);
		
				
	}//m
}//c
