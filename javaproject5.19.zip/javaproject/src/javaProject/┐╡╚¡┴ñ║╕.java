package javaProject;

import java.awt.Container;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;

import java.awt.Font;
import java.awt.Image;
import java.io.File;
import javax.swing.JMenuBar;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class ��ȭ���� extends JFrame {
	private JTextField textField;
	public ��ȭ����() {
		setTitle("��ȭ����");
		setSize(500, 500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uC5B4\uBCA4\uC838\uC2A4: \uC5D4\uB4DC\uAC8C\uC784");
		lblNewLabel.setFont(new Font("����", Font.BOLD, 30));
		lblNewLabel.setBounds(14, 12, 280, 42);
		getContentPane().add(lblNewLabel);
		
		JButton synopsis = new JButton("\uC904\uAC70\uB9AC");
		synopsis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		textField = new JTextField();
		textField.setText("\uC778\uD53C\uB2C8\uD2F0 \uC6CC \uC774\uD6C4 \uC808\uBC18\uB9CC \uC0B4\uC544\uB0A8\uC740 \uC9C0\uAD6C\r\n\uB9C8\uC9C0\uB9C9 \uD76C\uB9DD\uC774 \uB41C \uC5B4\uBCA4\uC838\uC2A4\r\n\uBA3C\uC800 \uB5A0\uB09C \uADF8\uB4E4\uC744 \uC704\uD574 \uBAA8\uB4E0 \uAC83\uC744 \uAC78\uC5C8\uB2E4!\r\n\r\n\uC704\uB300\uD55C \uC5B4\uBCA4\uC838\uC2A4\r\n\uC6B4\uBA85\uC744 \uBC14\uAFC0 \uCD5C\uD6C4\uC758 \uC804\uC7C1\uC774 \uD3BC\uCCD0\uC9C4\uB2E4!");
		textField.setBounds(14, 123, 454, 290);
		getContentPane().add(textField);
		textField.setColumns(10);
		synopsis.setBounds(14, 66, 105, 27);
		getContentPane().add(synopsis);
		
		
		
		
		setVisible(true);
		
	}
	
	
	public static void main(String[] args) {
		��ȭ���� infor = new ��ȭ����();
	}
}
