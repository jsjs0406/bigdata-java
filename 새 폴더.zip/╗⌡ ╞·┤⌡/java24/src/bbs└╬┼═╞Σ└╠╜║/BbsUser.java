package bbs�������̽�;

import �������̽�.MemberDAO;

public class BbsUser {

	public static void main(String[] args) {
		BbsDAO dao = new BbsDAO();
		BbsDTO dto = new BbsDTO("kim","kim","kim","kim");
		
		dao.insert(dto);
		dao.delete("kim");
		dao.update(dto);
		BbsDTO dto2 = dao.select("kim");
		

	}

}
