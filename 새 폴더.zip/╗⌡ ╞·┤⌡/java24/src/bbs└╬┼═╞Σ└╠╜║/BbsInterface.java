package bbs�������̽�;

public interface BbsInterface {
	public abstract void insert(BbsDTO dto);
	void delete(String id);
	void update(String dto);
	BbsDTO select(String id);
	
}
