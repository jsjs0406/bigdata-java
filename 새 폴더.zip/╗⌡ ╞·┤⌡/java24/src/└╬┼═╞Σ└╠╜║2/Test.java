package �������̽�2;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Test extends JFrame{
	public Test() {
		setSize(300, 300);
		JButton b = new JButton("���� ������.");
		add(b);
		ActionProcess action = new ActionProcess();
		b.addActionListener(action);
		setVisible(true);
		
	}
	public static void main(String[] args) {
		Test name = new Test();
	}

}
