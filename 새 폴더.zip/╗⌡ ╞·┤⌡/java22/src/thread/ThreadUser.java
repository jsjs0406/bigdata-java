package thread;

public class ThreadUser {

	public static void main(String[] args) {
		ForTest t1 = new ForTest();//������ ��ä ����
		ForTest2 t2 = new ForTest2();
		ForTest3 t3 = new ForTest3();
		
		t1.start();
		t2.start();
		t3.start();

	}

}
