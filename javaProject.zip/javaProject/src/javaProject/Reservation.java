package javaProject;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.GridLayout;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.FormSpecs;
import com.jgoodies.forms.layout.RowSpec;

public class Reservation extends JFrame {
	Reservation() {
		setTitle("���� ��ȭ��");
		setSize(500, 500);
		getContentPane().setLayout(null);
		
		
		JLabel titlelabel = new JLabel("\uC601\uD654\uC815\uBCF4");
		titlelabel.setBounds(85, 0, 296, 66);
		titlelabel.setFont(new Font("����", Font.BOLD, 70));
		titlelabel.setForeground(Color.BLACK);
		titlelabel.setHorizontalAlignment(SwingConstants.CENTER);
		getContentPane().add(titlelabel);
		
		JLabel label_18 = new JLabel("");
		label_18.setBounds(304, 46, 0, 0);
		getContentPane().add(label_18);
		
		JLabel label_19 = new JLabel("");
		label_19.setBounds(309, 46, 0, 0);
		getContentPane().add(label_19);
		
		JLabel label_20 = new JLabel("");
		label_20.setBounds(314, 46, 0, 0);
		getContentPane().add(label_20);
		
		JLabel label_21 = new JLabel("");
		label_21.setBounds(319, 46, 0, 0);
		getContentPane().add(label_21);
		
		JLabel label_22 = new JLabel("");
		label_22.setBounds(324, 46, 0, 0);
		getContentPane().add(label_22);
		
		JLabel label_23 = new JLabel("");
		label_23.setBounds(329, 46, 0, 0);
		getContentPane().add(label_23);
		
		JLabel label_6 = new JLabel("");
		label_6.setBounds(334, 46, 0, 0);
		getContentPane().add(label_6);
		
		JLabel label_7 = new JLabel("");
		label_7.setBounds(339, 46, 0, 0);
		getContentPane().add(label_7);
		
		JLabel label_8 = new JLabel("");
		label_8.setBounds(344, 46, 0, 0);
		getContentPane().add(label_8);
		
		JLabel label_9 = new JLabel("");
		label_9.setBounds(349, 46, 0, 0);
		getContentPane().add(label_9);
		
		JLabel label = new JLabel("");
		label.setBounds(354, 46, 0, 0);
		getContentPane().add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(359, 46, 0, 0);
		getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("");
		label_2.setBounds(364, 46, 0, 0);
		getContentPane().add(label_2);
		
		JLabel label_3 = new JLabel("");
		label_3.setBounds(369, 46, 0, 0);
		getContentPane().add(label_3);
		
		JLabel mnlabel = new JLabel("\uC601\uD654");
		mnlabel.setBounds(52, 95, 50, 45);
		mnlabel.setFont(new Font("����", Font.PLAIN, 23));
		getContentPane().add(mnlabel);
		
		JLabel label_24 = new JLabel("");
		label_24.setBounds(471, 46, 0, 0);
		getContentPane().add(label_24);
		
		JLabel label_25 = new JLabel("");
		label_25.setBounds(476, 46, 0, 0);
		getContentPane().add(label_25);
		
		JLabel label_26 = new JLabel("");
		label_26.setBounds(481, 46, 0, 0);
		getContentPane().add(label_26);
		
		JLabel label_27 = new JLabel("");
		label_27.setBounds(14, 102, 0, 0);
		getContentPane().add(label_27);
		
		JLabel label_28 = new JLabel("");
		label_28.setBounds(19, 102, 0, 0);
		getContentPane().add(label_28);
		
		JLabel label_29 = new JLabel("");
		label_29.setBounds(24, 102, 0, 0);
		getContentPane().add(label_29);
		
		JLabel label_10 = new JLabel("");
		label_10.setBounds(29, 102, 0, 0);
		getContentPane().add(label_10);
		
		JLabel label_11 = new JLabel("");
		label_11.setBounds(34, 102, 0, 0);
		getContentPane().add(label_11);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("����", Font.PLAIN, 15));
		comboBox.setBounds(114, 111, 133, 21);
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		
		JLabel label_4 = new JLabel("");
		label_4.setBounds(39, 102, 0, 0);
		getContentPane().add(label_4);
		
		JLabel label_5 = new JLabel("");
		label_5.setBounds(44, 102, 0, 0);
		getContentPane().add(label_5);
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"\uC120\uD0DD", "AvengersEndgame", "\uAC78\uCE85\uC2A4", "\uB098\uC758\uD2B9\uBCC4\uD55C\uD615\uC81C"}));
		getContentPane().add(comboBox);
		
		JLabel lblNewLabel = new JLabel("\uC9C0\uC5ED");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 23));
		lblNewLabel.setBounds(52, 152, 57, 29);
		getContentPane().add(lblNewLabel);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setFont(new Font("����", Font.PLAIN, 15));
		comboBox_1.setBounds(114, 160, 86, 21);
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"\uC120\uD0DD", "\uAC00\uC0B0\uB514\uC9C0\uD138", "\uB3C5\uC0B0", "\uD64D\uB300\uC785\uAD6C", "\uC2E0\uB3C4\uB9BC"}));
		getContentPane().add(comboBox_1);
		
		JLabel label_30 = new JLabel("");
		label_30.setBounds(307, 102, 0, 0);
		getContentPane().add(label_30);
		
		JLabel label_31 = new JLabel("");
		label_31.setBounds(312, 102, 0, 0);
		getContentPane().add(label_31);
		
		JLabel lblNewLabel_1 = new JLabel("\uB0A0\uC9DC");
		lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 23));
		lblNewLabel_1.setBounds(52, 207, 50, 29);
		getContentPane().add(lblNewLabel_1);
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setFont(new Font("����", Font.PLAIN, 13));
		comboBox_2.setBounds(112, 211, 50, 25);
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"1\uC6D4", "2\uC6D4", "3\uC6D4", "4\uC6D4", "5\uC6D4", "6\uC6D4", "7\uC6D4", "8\uC6D4", "9\uC6D4", "10\uC6D4", "11\uC6D4", "12\uC6D4"}));
		getContentPane().add(comboBox_2);
		
		JLabel label_32 = new JLabel("");
		label_32.setBounds(401, 102, 0, 0);
		getContentPane().add(label_32);
		
		JLabel label_33 = new JLabel("");
		label_33.setBounds(406, 102, 0, 0);
		getContentPane().add(label_33);
		
		JLabel label_34 = new JLabel("");
		label_34.setBounds(411, 102, 0, 0);
		getContentPane().add(label_34);
		
		JLabel label_35 = new JLabel("");
		label_35.setBounds(416, 102, 0, 0);
		getContentPane().add(label_35);
		
		JLabel label_36 = new JLabel("");
		label_36.setBounds(421, 102, 0, 0);
		getContentPane().add(label_36);
		
		JLabel label_37 = new JLabel("");
		label_37.setBounds(426, 102, 0, 0);
		getContentPane().add(label_37);
		
		JLabel label_38 = new JLabel("");
		label_38.setBounds(431, 102, 0, 0);
		getContentPane().add(label_38);
		
		JLabel label_39 = new JLabel("");
		label_39.setBounds(436, 102, 0, 0);
		getContentPane().add(label_39);
		
		JLabel label_40 = new JLabel("");
		label_40.setBounds(441, 102, 0, 0);
		getContentPane().add(label_40);
		
		JLabel label_12 = new JLabel("");
		label_12.setBounds(446, 102, 0, 0);
		getContentPane().add(label_12);
		
		JLabel label_13 = new JLabel("");
		label_13.setBounds(451, 102, 0, 0);
		getContentPane().add(label_13);
		
		JLabel label_14 = new JLabel("");
		label_14.setBounds(456, 102, 0, 0);
		getContentPane().add(label_14);
		
		JLabel label_15 = new JLabel("");
		label_15.setBounds(461, 102, 0, 0);
		getContentPane().add(label_15);
		
		JComboBox comboBox_3 = new JComboBox();
		comboBox_3.setFont(new Font("����", Font.PLAIN, 13));
		comboBox_3.setBounds(174, 211, 50, 25);
		comboBox_3.setModel(new DefaultComboBoxModel(new String[] {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		getContentPane().add(comboBox_3);
		
		JLabel lblNewLabel_2 = new JLabel("\uC0C1\uC601\uAD00");
		lblNewLabel_2.setFont(new Font("����", Font.PLAIN, 23));
		lblNewLabel_2.setBounds(52, 252, 76, 45);
		getContentPane().add(lblNewLabel_2);
		
		JLabel label_41 = new JLabel("");
		label_41.setBounds(168, 128, 0, 0);
		getContentPane().add(label_41);
		
		JLabel label_42 = new JLabel("");
		label_42.setBounds(173, 128, 0, 0);
		getContentPane().add(label_42);
		
		JLabel label_43 = new JLabel("");
		label_43.setBounds(178, 128, 0, 0);
		getContentPane().add(label_43);
		
		JLabel label_44 = new JLabel("");
		label_44.setBounds(183, 128, 0, 0);
		getContentPane().add(label_44);
		
		JLabel label_45 = new JLabel("");
		label_45.setBounds(188, 128, 0, 0);
		getContentPane().add(label_45);
		
		JLabel label_46 = new JLabel("");
		label_46.setBounds(193, 128, 0, 0);
		getContentPane().add(label_46);
		
		JComboBox comboBox_4 = new JComboBox();
		comboBox_4.setBounds(134, 268, 44, 21);
		comboBox_4.setModel(new DefaultComboBoxModel(new String[] {"1\uAD00", "2\uAD00", "3\uAD00", "4\uAD00", "5\uAD00"}));
		getContentPane().add(comboBox_4);
		
		JLabel label_16 = new JLabel("");
		label_16.setBounds(247, 128, 0, 0);
		getContentPane().add(label_16);
		
		JLabel label_17 = new JLabel("");
		label_17.setBounds(252, 128, 0, 0);
		getContentPane().add(label_17);
		
		JLabel label_47 = new JLabel("");
		label_47.setBounds(257, 128, 0, 0);
		getContentPane().add(label_47);
		
		JLabel label_48 = new JLabel("");
		label_48.setBounds(262, 128, 0, 0);
		getContentPane().add(label_48);
		
		JLabel label_49 = new JLabel("");
		label_49.setBounds(267, 128, 0, 0);
		getContentPane().add(label_49);
		
		JLabel label_50 = new JLabel("");
		label_50.setBounds(272, 128, 0, 0);
		getContentPane().add(label_50);
		
		JLabel label_51 = new JLabel("");
		label_51.setBounds(277, 128, 0, 0);
		getContentPane().add(label_51);
		
		JLabel label_52 = new JLabel("");
		label_52.setBounds(282, 128, 0, 0);
		getContentPane().add(label_52);
		
		JLabel label_53 = new JLabel("");
		label_53.setBounds(287, 128, 0, 0);
		getContentPane().add(label_53);
		
		JLabel label_54 = new JLabel("");
		label_54.setBounds(292, 128, 0, 0);
		getContentPane().add(label_54);
		
		JLabel label_55 = new JLabel("");
		label_55.setBounds(297, 128, 0, 0);
		getContentPane().add(label_55);
		
		JLabel label_56 = new JLabel("");
		label_56.setBounds(302, 128, 0, 0);
		getContentPane().add(label_56);
		
		JLabel label_57 = new JLabel("");
		label_57.setBounds(307, 128, 0, 0);
		getContentPane().add(label_57);
		
		JLabel label_58 = new JLabel("");
		label_58.setBounds(312, 128, 0, 0);
		getContentPane().add(label_58);
		
		JLabel label_59 = new JLabel("");
		label_59.setBounds(317, 128, 0, 0);
		getContentPane().add(label_59);
		
		JLabel label_60 = new JLabel("");
		label_60.setBounds(322, 128, 0, 0);
		getContentPane().add(label_60);
		
		JLabel label_61 = new JLabel("");
		label_61.setBounds(327, 128, 0, 0);
		getContentPane().add(label_61);
		
		JLabel label_62 = new JLabel("");
		label_62.setBounds(332, 128, 0, 0);
		getContentPane().add(label_62);
		
		JLabel label_63 = new JLabel("");
		label_63.setBounds(337, 128, 0, 0);
		getContentPane().add(label_63);
		
		JLabel label_64 = new JLabel("");
		label_64.setBounds(342, 128, 0, 0);
		getContentPane().add(label_64);
		
		JLabel label_65 = new JLabel("");
		label_65.setBounds(347, 128, 0, 0);
		getContentPane().add(label_65);
		
		JLabel label_66 = new JLabel("");
		label_66.setBounds(352, 128, 0, 0);
		getContentPane().add(label_66);
		
		JLabel label_67 = new JLabel("");
		label_67.setBounds(357, 128, 0, 0);
		getContentPane().add(label_67);
		
		setVisible(true);
	}
	public static void main(String[] args) {
		new Reservation();
		
	}
	

}
