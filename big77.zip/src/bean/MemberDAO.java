package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


public class MemberDAO {
	
	DBConnectionMgr mgr;
	
	public MemberDAO(){
		
		mgr = DBConnectionMgr.getInstance();
		
	}
	//제너릭 프로그래밍(객체생성시 어떤 타입을 결정가능)
	//형변환 필요없엇 내부적인 처리 속도가 더 빠름.
	public ArrayList<MemberDTO> selectAll() throws Exception {
		
		ArrayList<MemberDTO> list = new ArrayList<MemberDTO>();
		// 1,2단계를 해주는 DBConnectionmgr객체 필요
		Connection con = mgr.getConnection();
				
		// 3단계 sql문 결정
		String sql = "select * from member";
		PreparedStatement ps = con.prepareStatement(sql);
		
		//4단계 sql문 전달 요청
		ResultSet rs = ps.executeQuery();
		MemberDTO dto2 = null;
		while(rs.next()) {
			dto2 = new MemberDTO();
			String id = rs.getString(1);
			String pw = rs.getString(2);
			String name = rs.getString(3);
			String tel = rs.getString(4);
			
			dto2.setId(id);
			dto2.setPw(pw);
			dto2.setName(name);
			dto2.setTel(tel);
			list.add(dto2);
		}
		return list;
	}
	public MemberDTO select(MemberDTO dto) throws Exception {
	      Connection con = mgr.getConnection();
	      
	      //3단계 sql문 결정
	      String sql = "select * from member where id=?";
	      PreparedStatement ps = con.prepareStatement(sql);
	      ps.setString(1, dto.getId());
	      
	      //4단계 sql 전달 요청
	      ResultSet rs = ps.executeQuery();
	      MemberDTO dto2 = null;
	      while(rs.next()) {
	         dto2 = new MemberDTO();
	         String id = rs.getString(1);
	         String pw =rs.getString(2);
	         String name =rs.getString(3);
	         String tel = rs.getString(4);
	         dto2.setId(id);
	         dto2.setPw(pw);
	         dto2.setName(name);
	         dto2.setTel(tel);
	      }
	      return dto2;
	   }

}