package money;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.mysql.jdbc.Connection;

public class BankDAO {
	java.sql.Connection con;
	java.sql.PreparedStatement ps;
	ResultSet rs;
	String url;
	String user;
	String password;
	
	public void insert(BankDTO dto) throws Exception {
		// 1.드라이버 설정
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("1.드라이버 설정 완료");

		// db연결
		url = "jdbc:mysql://localhost:3306/bank";
		user = "root";
		password = "1234";
		con = DriverManager.getConnection(url, user, password);

		// sql문
		String sql = "insert into member values(?,?,?,?)";
		ps = con.prepareStatement(sql);
		ps.setString(1, dto.getId());
		ps.setString(2, dto.getName());
		ps.setString(3, dto.getAge());
		ps.setString(4, dto.getTel());
		System.out.println("sql문 결정 완료");

		// sql문 전송
		ps.executeUpdate();
		System.out.println("sql문 전송 완료");

	}

	public void delete(BankDTO dto) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");

		url = "jdbc:mysql://localhost:3306/bank";
		user = "root";
		password = "1234";
		con = DriverManager.getConnection(url, user, password);

		String sql = "delete from member where id = ?";
		ps = con.prepareStatement(sql);
		ps.setString(1, dto.getId());

		ps.executeUpdate();

	}

	public void update(BankDTO dto) throws Exception {

		Class.forName("com.mysql.jdbc.Driver");
		url = "jdbc:mysql://localhost:3306/bank";
		user = "root";
		password = "1234";
		con = DriverManager.getConnection(url, user, password);

		String sql = "update member set tel =? where id =?";

		ps = con.prepareStatement(sql);
		ps.setString(1, dto.getId());
		ps.setString(2, dto.getTel());

		ps.executeUpdate();

	}
	public BankDTO select(String inputId) {
		BankDTO dto = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			url = "jdbc:mysql://localhost:3306/bank";
			user = "root";
			password = "1234";
			con = DriverManager.getConnection(url, user, password);
			
			String sql = "selcet * from member where id =?";
			
			ps = con.prepareStatement(sql);
			ps.setString(1, inputId);
			rs = ps.executeQuery();
			if (rs.next()) {
				dto = new BankDTO();
				String id = rs.getString(1);
				String name = rs.getString(2);
				String age = rs.getString(3);
				String tel = rs.getString(4);
				dto.setId(id);
				dto.setName(name);
				dto.setAge(age);
				dto.setTel(tel);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				con.close();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		
		}
		return dto;
	}
	public ArrayList selectAll() {
		ArrayList list = new ArrayList();
		BankDTO dto = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			url = "jdbc:mysql://localhost:3306/bank";
			user = "root";
			password = "1234";
			con = DriverManager.getConnection(url, user, password);
			
			String sql = "selcet * from member";
			
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				dto = new BankDTO();
				String id = rs.getString(1);
				String name = rs.getString(2);
				String age = rs.getString(3);
				String tel = rs.getString(4);
				dto.setId(id);
				dto.setName(name);
				dto.setAge(age);
				dto.setTel(tel);
				
				list.add(dto);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				con.close();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		
		}
		return list;
	}
}