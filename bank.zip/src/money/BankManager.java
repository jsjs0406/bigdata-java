package money;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class BankManager {
	private JTextField idText;
	private JTextField nameText;
	private JTextField ageText;
	private JTextField telText;
	private JTextField inputIdText;
	public BankManager() {
  JFrame f = new JFrame("은행 고객관리 시스템");
  f.getContentPane().setBackground(new Color(47, 79, 79));
  f.setSize(400, 709);
  FlowLayout flow = new FlowLayout();
  f.getContentPane().setLayout(flow);
  
  JLabel lblNewLabel = new JLabel("<<아이디>>");
  lblNewLabel.setForeground(new Color(0, 0, 205));
  lblNewLabel.setFont(new Font("굴림", Font.BOLD, 29));
  f.getContentPane().add(lblNewLabel);
  
  idText = new JTextField();
  idText.setForeground(new Color(0, 0, 0));
  idText.setBackground(new Color(255, 255, 0));
  idText.setFont(new Font("굴림", Font.BOLD, 27));
  f.getContentPane().add(idText);
  idText.setColumns(10);
  
  JLabel label = new JLabel("<<이름>>");
  label.setForeground(new Color(0, 0, 205));
  label.setFont(new Font("굴림", Font.BOLD, 29));
  f.getContentPane().add(label);
  
  nameText = new JTextField();
  nameText.setForeground(new Color(128, 0, 0));
  nameText.setBackground(new Color(255, 255, 0));
  nameText.setFont(new Font("굴림", Font.BOLD, 27));
  nameText.setColumns(10);
  f.getContentPane().add(nameText);
  
  JLabel label_1 = new JLabel("<<나이>>");
  label_1.setForeground(new Color(0, 0, 205));
  label_1.setFont(new Font("굴림", Font.BOLD, 29));
  f.getContentPane().add(label_1);
  
  ageText = new JTextField();
  ageText.setForeground(new Color(128, 0, 0));
  ageText.setBackground(new Color(255, 255, 0));
  ageText.setFont(new Font("굴림", Font.BOLD, 27));
  ageText.setColumns(10);
  f.getContentPane().add(ageText);
  
  JLabel label_2 = new JLabel("<<전화번호>>");
  label_2.setForeground(new Color(0, 0, 205));
  label_2.setFont(new Font("굴림", Font.BOLD, 29));
  f.getContentPane().add(label_2);
  
  telText = new JTextField();
  telText.setForeground(new Color(128, 0, 0));
  telText.setBackground(new Color(255, 255, 0));
  telText.setFont(new Font("굴림", Font.BOLD, 27));
  telText.setColumns(10);
  f.getContentPane().add(telText);
  
  JButton btnNewButton = new JButton("데이타 검색하기");
  btnNewButton.addActionListener(new ActionListener() {
  public void actionPerformed(ActionEvent arg0) {
  String inputId = idText.getText();
  BankDAO dao = new BankDAO();
  BankDTO dto = dao.select(inputId);
  String id = dto.getId();
  String name = dto.getName();
  String age = dto.getAge();
  String tel = dto.getTel();
  
  idText.setText(id);
  nameText.setText(name);
  ageText.setText(age);
  telText.setText(tel);

  }
  });
  
  JButton button = new JButton("데이타 입력하기");
  button.addActionListener(new ActionListener() {
  public void actionPerformed(ActionEvent arg0) {
  BankDAO dao = new BankDAO();
  BankDTO dto = new BankDTO();
  String id = idText.getText();
  String name = nameText.getText();
  String age = ageText.getText();
  String tel = telText.getText();
  dto.setId(id);
  dto.setName(name);
  dto.setAge(age);
  dto.setTel(tel);
  try {
	dao.insert(dto);
} catch (Exception e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
  

  }
  });
  JLabel label_3 = new JLabel("<<수정할ID>>");
  label_3.setForeground(new Color(0, 0, 205));
  label_3.setFont(new Font("굴림", Font.BOLD, 29));
  f.getContentPane().add(label_3);
  
  inputIdText = new JTextField();
  inputIdText.setForeground(new Color(128, 0, 0));
  inputIdText.setFont(new Font("굴림", Font.BOLD, 27));
  inputIdText.setColumns(10);
  inputIdText.setBackground(Color.YELLOW);
  f.getContentPane().add(inputIdText);
  button.setFont(new Font("굴림", Font.BOLD, 25));
  button.setBackground(new Color(50, 205, 50));
  f.getContentPane().add(button);
  btnNewButton.setBackground(new Color(50, 205, 50));
  btnNewButton.setFont(new Font("굴림", Font.BOLD, 25));
  f.getContentPane().add(btnNewButton);
  
  JButton button_1 = new JButton("데이타 수정하기");
  button_1.addActionListener(new ActionListener() {
  public void actionPerformed(ActionEvent arg0) {
  BankDAO dao = new BankDAO();
  BankDTO dto = new BankDTO();
  String id = inputIdText.getText();
  String tel = telText.getText();

  dto.setId(id);
  dto.setTel(tel);
 
  }
  });
  button_1.setBackground(new Color(50, 205, 50));
  button_1.setFont(new Font("굴림", Font.BOLD, 25));
  f.getContentPane().add(button_1);
  
  JButton button_2 = new JButton("데이타 삭제하기");
  button_2.addActionListener(new ActionListener() {
  public void actionPerformed(ActionEvent e) {
  BankDAO dao = new BankDAO();
  BankDTO dto = new BankDTO();
  String id = idText.getText();
  dto.setId(id);
  try {
	dao.delete(dto);
} catch (Exception e1) {
	// TODO Auto-generated catch block
	e1.printStackTrace();
}
  }
  });
  button_2.setBackground(new Color(50, 205, 50));
  button_2.setFont(new Font("굴림", Font.BOLD, 25));
  f.getContentPane().add(button_2);
  
  JButton button_3 = new JButton("데이타 전체 검색하기");
  button_3.addActionListener(new ActionListener() {
  	public void actionPerformed(ActionEvent e) {

        BankDAO dao = new BankDAO();
        ArrayList list = dao.selectAll();
     
        System.out.println("id    name    age    tel");
     for (int i = 0; i < list.size(); i++) {
        BankDTO dto = (BankDTO)list.get(i);
        System.out.print((i+1)+"번 : ");
            System.out.print(dto.getId()+"  ");
            System.out.print("     "+dto.getName()+" ");
            System.out.print("     "+dto.getAge()+" ");
            System.out.print("     "+dto.getTel()+" ");
            System.out.println();
     }
     
     try {
        dao.selectAll();
     } catch (Exception e1) {
        e1.printStackTrace();
     }
  	}
  });
  button_3.setFont(new Font("굴림", Font.BOLD, 25));
  button_3.setBackground(new Color(50, 205, 50));
  f.getContentPane().add(button_3);
  
  
  f.setVisible(true);
	}
	public static void main(String[] args) {
  BankManager bankManager = new BankManager();
	}
}