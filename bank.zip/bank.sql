create database bank;
use bank;
mysql> create table member (
    -> id varchar(20) primary key,
    -> name varchar(20),
    -> age varchar(10),
    -> tel varchar(20)
    -> );