package com.itbank.mvcSpring;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller//컨트롤러 실행
public class MusicController {
	@Autowired//dao 불러오기
	MusicDAO dao;
	
	@RequestMapping("insert.do")
	public void insert(MusicDTO musicDTO) {
		dao.insert(musicDTO);
		System.out.println("insert요청");
		
	}
	@RequestMapping("update.do")
	public void update(MusicDTO musicDTO) {
		dao.update(musicDTO);
		System.out.println("update요청");
		
	}
	
	@RequestMapping("delete.do")
	public void delete(MusicDTO musicDTO) {
		dao.delete(musicDTO);
		System.out.println("delete요청");
		
	}
	@RequestMapping("select.do")
	public void select(MusicDTO musicDTO,Model model) {
		MusicDTO dto = dao.select(musicDTO);
		model.addAttribute("dto",dto);
		
	}
	@RequestMapping("selectAll.do")
	public void selectAll(MusicDTO musicDTO,Model model) {
		List<MusicDTO> list = dao.selectAll();
		model.addAttribute("list",list);
	}

	
	
	
}
