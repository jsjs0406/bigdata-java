package com.itbank.mvcSpring;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class MusicDAO {
	@Autowired
	SqlSessionTemplate my;
	public void insert(MusicDTO musicDTO) {
		my.insert("mDAO.insert", musicDTO);
		System.out.println("myBatis 호출");
		
	}
	public void delete(MusicDTO musicDTO) {
		my.delete("mDAO.delete", musicDTO);
		
	}
	public void update(MusicDTO musicDTO) {
		my.update("mDAO.update", musicDTO);
		
	}
	public MusicDTO select(MusicDTO musicDTO) {
		return my.selectOne("mDAO.select", musicDTO);
		
	}
	public List<MusicDTO> selectAll() {
		return my.selectList("mDAO.selectAll");
		
	}

}
