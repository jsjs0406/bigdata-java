package ����1;

public class NormalBank extends Bank{

	
	@Override
	public double getInterestRate() {
		double rete = 5.0;
		return rete;
	}

}
