package java17;
import java.util.ArrayList;
public class ArrayList {

	public static void main(String[] args) {
		ArrayList list = new ArrayList();
		list.add("���� ��Ʈ��");
		list.add(100);
		list.add(11.22);
		list.add('A');
		System.out.println(list);

	}

}
