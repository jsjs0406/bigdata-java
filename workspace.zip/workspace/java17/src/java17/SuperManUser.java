package java17;

public class SuperManUser {

	public static void main(String[] args) {
		SuperMan sMan = new SuperMan();
		sMan.height = 200;//person
		sMan.weight = 100;//person
		sMan.eye = 3;//man
		sMan.fly = true;//superman
		System.out.println(sMan);
		sMan.eat();//person
		sMan.sleep();
		sMan.army();
		sMan.flySpeed();
		

	}

}
