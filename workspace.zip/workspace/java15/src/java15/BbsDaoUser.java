package java15;

public class BbsDaoUser {

}
