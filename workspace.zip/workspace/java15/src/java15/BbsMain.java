package java15;

import java.awt.FlowLayout;
import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.xml.soap.Text;

import collection.BbsDAO;
import collection.BbsDTO;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class BbsMain {
	private JTextField idText;
	private JTextField titleText;
	private JTextField contentText;
	private JTextField etcText;

	public BbsMain() {
		JFrame f = new JFrame("���� �Խ��� �����");
		f.getContentPane().setBackground(Color.GREEN);
		f.setSize(411, 608);
		FlowLayout flow = new FlowLayout();
		f.getContentPane().setLayout(flow);

		JLabel lblNewLabel = new JLabel("<\uC544\uC774\uB514>");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 30));
		lblNewLabel.setForeground(Color.BLUE);
		lblNewLabel.setBackground(Color.WHITE);
		f.getContentPane().add(lblNewLabel);

		idText = new JTextField();
		idText.setFont(new Font("����", Font.PLAIN, 30));
		idText.setBackground(Color.YELLOW);
		f.getContentPane().add(idText);
		idText.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("<<\uC81C\uBAA9>>");
		lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 30));
		lblNewLabel_1.setForeground(Color.BLUE);
		f.getContentPane().add(lblNewLabel_1);

		titleText = new JTextField();
		titleText.setBackground(Color.YELLOW);
		titleText.setFont(new Font("����", Font.PLAIN, 30));
		f.getContentPane().add(titleText);
		titleText.setColumns(10);

		JLabel lblNewLabel_2 = new JLabel("<<\uB0B4\uC6A9>>");
		lblNewLabel_2.setFont(new Font("����", Font.PLAIN, 30));
		lblNewLabel_2.setForeground(Color.BLUE);
		f.getContentPane().add(lblNewLabel_2);

		contentText = new JTextField();
		contentText.setFont(new Font("����", Font.PLAIN, 30));
		contentText.setBackground(Color.YELLOW);
		f.getContentPane().add(contentText);
		contentText.setColumns(10);

		JLabel lblNewLabel_3 = new JLabel("<<\uAE30\uD0C0>>");
		lblNewLabel_3.setFont(new Font("����", Font.PLAIN, 30));
		lblNewLabel_3.setForeground(Color.BLUE);
		f.getContentPane().add(lblNewLabel_3);

		etcText = new JTextField();
		etcText.setBackground(Color.YELLOW);
		etcText.setFont(new Font("����", Font.PLAIN, 30));
		f.getContentPane().add(etcText);
		etcText.setColumns(10);

		JButton btnNewButton = new JButton("Bbs\uAC80\uC0C9\uD558\uAE30");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String inputid = idText.getText();
				BbsDAOUser dao = new BbsDAOUser();
				BbsDTO dto = dao.select(inputid);
				String id = dto.getId();
				String title = dto.getTitle();
				String content = dto.getContent();
				String etc = dto.getEtc();
				idText.setText(id);
				titleText.setText(title);
				contentText.setText(content);
				etcText.setText(etc);

			}
		});
		btnNewButton.setFont(new Font("����", Font.PLAIN, 20));
		btnNewButton.setBackground(Color.MAGENTA);
		f.getContentPane().add(btnNewButton);
		
		JButton btnInsert = new JButton("Insert");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
			String inputid = idText.getText();
			BbsDAOUser dao = new BbsDAOUser();
			BbsDTO dto = new BbsDTO();
			String id = dto.getId();
			String title = dto.getTitle();
			String content = dto.getContent();
			String etc = dto.getEtc();

				
			}
		});
		btnInsert.setFont(new Font("����", Font.PLAIN, 20));
		btnInsert.setBackground(Color.MAGENTA);
		f.getContentPane().add(btnInsert);

		f.setVisible(true);

	}
	public static void main(String[]args) {
		BbsMain name = new BbsMain();
	}

}
