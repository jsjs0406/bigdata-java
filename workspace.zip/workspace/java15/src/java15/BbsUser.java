package java15;

import java.util.Scanner;

import collection.BbsDAO;
import collection.BbsDTO;

public class BbsUser {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("�˻��� id�Է�>>>");
		String inputId = sc.next();
		//String title = sc.next();
		//String content = sc.next();
		//String etc = sc.next();
		
		BbsDAOUser dao = new BbsDAOUser();
		BbsDTO dto = dao.select(inputId);
		System.out.println("�˻��� id: " + dto.getId());
		System.out.println("�˻��� title: " + dto.getTitle());
		System.out.println("�˻��� content: " + dto.getContent());
		System.out.println("�˻��� etc: " + dto.getEtc());

	}

}
