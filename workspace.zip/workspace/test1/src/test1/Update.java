package test1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Update {
	String url = "jdbc:mysql://localhost:3306/car";
	String user = "root";
	String password = "1234";

	Connection con;
	PreparedStatement ps;
	public void update(CarDTO dto) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, user, password);
			String sql = "update carSale set price = ? where id = ?";
			ps = con.prepareStatement(sql);
			ps.setString(1, dto.getPrice());
			ps.setString(2, dto.getId());
			dto.setPrice(price);
			dto.setId(id);
			
			ps.executeUpdate();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
		
		}try {
			ps.close();
			con.close();
		
			
		} catch (Exception e) {
			// TODO: handle exception
		} 
			
		
	
	
	


	}
}
