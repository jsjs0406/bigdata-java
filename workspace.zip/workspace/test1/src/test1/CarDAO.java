package test1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class CarDAO {
	String url = "jdbc:mysql://localhost:3306/car";
	String user = "root";
	String password = "1234";

	Connection con;
	PreparedStatement ps;
	ResultSet rs;

	public ArrayList selectAll() {

		CarDTO dto = null;
		ArrayList list = new ArrayList();

		try {
			Class.forName("com.mysql.jdbc.Driver");//
			con = DriverManager.getConnection(url, user, password);
			String sql = "select * from carsale";//
			ps = con.prepareStatement(sql);
			ps.executeQuery();
			System.out.println("db �Ϸ�");

			while (rs.next()) {
				dto = new CarDTO();
				String id = rs.getString(1);
				String name = rs.getString(2);
				String content = rs.getString(3);
				String price = rs.getString(4);
				dto.setId(id);
				dto.setName(name);
				dto.setContent(content);
				dto.setPrice(price);
				
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				ps.close();
				con.close();
				rs.close();
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		return list;

	}

//	public void insert(CarDTO dto) {
//		try {
//			Class.forName("com.mysql.jdbc.Driver");
//			con = DriverManager.getConnection(url, user, password);
//			String sql = "insert into carSale values(?,?,?,?)";
//			ps= con.prepareStatement(sql);
//			ps.setString(1, dto.getId());
//			ps.setString(2, dto.getName());
//			ps.setString(3, dto.getContent());
//			ps.setString(4, dto.getPrice());
//		
//			ps.executeUpdate();
//			
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//		}

//		public CarDTO select (String inputId) {
//			CarDTO dto = null;
//			try {
//				Class.forName("com.mysql.jdbc.Driver");
//				con = DriverManager.getConnection(url, user, password);
//				String sql = "select * from carSale where id = ?";
//				ps = con.prepareStatement(sql);
//				ps.setString(1, inputId);
//				rs= ps.executeQuery();
//				if(rs.next()) {
//					dto = new CarDTO();
//					String id = rs.getString(1);
//					String name = rs.getString(2);
//					String content = rs.getString(3);
//					String price = rs.getString(4);
//					dto.setId(id);
//					dto.setName(name);
//					dto.setContent(content);
//					dto.setPrice(price);
//				}
//				
//				
//			} catch (Exception e) {
//				e.printStackTrace();
//			}finally {
//				try {
//					rs.close();
//					ps.close();
//					con.close();
//					
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//			
//			return dto;
//		}
//		public void update(CarDTO dto) {
//			try {
//				Class.forName("com.mysql.jdbc.Driver");
//				con = DriverManager.getConnection(url, user, password);
//				String sql = "update carSale set price = ? where id = ?";
//				ps = con.prepareStatement(sql);
//				ps.setString(1, dto.getPrice());
//				ps.setString(2, dto.getId());
//				ps.executeUpdate();
//				
//				
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//		}
//		public void delete(CarDTO dto) {
//			try {
//				Class.forName("com.mysql.jdbc.Driver");
//				con = DriverManager.getConnection(url, user, password);
//				String sql = "delete from carSale where id = ?";
//				ps = con.prepareStatement(sql);
//				ps.setString(1, dto.getId());
//				ps.executeUpdate();
//				
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//		}
//		
//		
//		
//	}

}
