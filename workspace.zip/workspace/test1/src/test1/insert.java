package test1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class insert {
	String url = "jdbc:mysql://localhost:3306/car";
	String user = "root";
	String password = "1234";

	Connection con;
	PreparedStatement ps;


	public void insert(CarDTO dto) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, user, password);
			String sql = "insert into carSale values(?,?,?,?)";
			ps= con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			ps.setString(2, dto.getName());
			ps.setString(3, dto.getContent());
			ps.setString(4, dto.getPrice());
		
			ps.executeUpdate();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	

}
