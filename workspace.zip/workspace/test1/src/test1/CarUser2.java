//package test1;
//
//import java.util.Scanner;
//
//public class CarUser2 {
//
//	public static void main(String[] args) {
//		Scanner sc = new Scanner(System.in);
//		System.out.print("�˻��� ���̵� �Է� :");
//		String inputId = sc.next();
//		
//		CarDAO dao = new CarDAO();
//		CarDTO dto = dto.select(inputId);
//		System.out.println("�˻���id : + dto.get");
//		
//		
//		
//		
//	}
//
//}
