package project;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.BorderLayout;
import javax.swing.JLabel;

public class Reservation {
	static int status = 0;// ���� ��ġ��

	public static void main(String[] args) {
		JFrame f = new JFrame();
		String[] movies = { "a1.jpg", "g1.jpg", "p1.jpg" };
		JButton[] buttons = new JButton[2];
		JButton icon = new JButton()

		f.setTitle("��ȭ ���� �ý���");
		f.setSize(400, 700);
		FlowLayout flow = new FlowLayout();
		JButton jpg = new JButton();
		f.getContentPane().add(jpg);

		ImageIcon icon = new ImageIcon("a1.jpg");
		jpg.setIcon(icon);

		JButton lb = new JButton("\u25C0");
		lb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (status < 0) {
					status = 2;
				} else {
					status-=1;
					JOptionPane.showMessageDialog(null, "������ ��ȭ�Դϴ�.");
				}
				ImageIcon icon = new ImageIcon(jpg[status]);
				jpg.setIcon(icon);

			}
		});
		lb.setBounds(78, 301, 97, 23);
		f.getContentPane().add(lb, BorderLayout.WEST);

		JButton rb = new JButton("\u25B6");
		rb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (status + 1 <= 2) {
					ImageIcon icon = new ImageIcon(movies[status + 1]);
					jpg.setIcon(icon);
					status = status + 1;
				} else {
					JOptionPane.showMessageDialog(null, "������ ��ȭ�Դϴ�.");
				}
			}
		});
		rb.setBounds(246, 301, 97, 23);
		f.getContentPane().add(rb, BorderLayout.EAST);


		f.setVisible(true);

	}
}
