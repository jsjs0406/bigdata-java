package project;

import javax.swing.JOptionPane;


public class Ƽ�ϵ���Է� {

	public static void main(String[] args) {
		String mname = JOptionPane.showInputDialog("�����Է�:");
		String city = JOptionPane.showInputDialog("city�Է�:");
		String day = JOptionPane.showInputDialog("day�Է�:");
		String hall = JOptionPane.showInputDialog("hall�Է�:");
		String time = JOptionPane.showInputDialog("time�Է�:");
		String seat = JOptionPane.showInputDialog("seat�Է�:");
		String price = JOptionPane.showInputDialog("price�Է�:");
		TicketDao db = new TicketDao();
		
		try {
			db.insert(mname, city, day, hall, time, seat, price);
		} catch (Exception e) {
			System.out.println("�����߻�!!!�����߻�!!!");
		}

	}

}
