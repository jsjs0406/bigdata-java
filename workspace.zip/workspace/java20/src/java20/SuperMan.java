package java20;

public class SuperMan extends Man {
	int weight;
	String fly;

	public SuperMan() {
		System.out.println("Superman��ü����");
	}

	public SuperMan(int weight, String fly) {
		//super();
		this.weight = weight;
		this.fly = fly;
	}

	public SuperMan(int eye, int hight, int weight, String fly) {
	super(eye, hight);
		this.weight = weight;
		this.fly = fly;
	}

}
