package java20;

public class ManUser {

	public static void main(String[] args) {
		Man m = new Man();

	}

}
