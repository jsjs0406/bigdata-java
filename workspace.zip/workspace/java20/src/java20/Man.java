package java20;

public class Man {
	int eye;
	int hight;
	
	public Man() {
		// TODO Auto-generated constructor stub
	}
	public Man(int eye, int hight) {
		super();
		this.eye = eye;
		this.hight = hight;
	}
	
	

}
