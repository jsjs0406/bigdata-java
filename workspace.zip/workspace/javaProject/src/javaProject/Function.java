package javaProject;

import java.awt.Font;

import javax.swing.Icon;
import javax.swing.JFrame;
import javax.swing.JLabel;


public abstract class Function extends JFrame {
	public abstract void List_AvengersEndgame();
	public abstract void List_��İ��();
	public abstract void List_����Ư��������();
}
class List extends Function{

	@Override
	public void List_AvengersEndgame() {
		JLabel mname = new JLabel("��ȭ��: Avengers Endgame");
		TicketReservation.contentpane.add;
		
		
		
				
			
		
	}

	@Override
	public void List_��İ��() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void List_����Ư��������() {
		// TODO Auto-generated method stub
		
	}
	
}
	
	
	
	



