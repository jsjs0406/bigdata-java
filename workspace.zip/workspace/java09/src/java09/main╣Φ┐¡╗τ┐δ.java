package java09;

public class main배열사용 {

	public static void main(String[] args) {
		System.out.println(args[0]);
		System.out.println(args[1]);

	}

}
