package java09;

import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class 문제2 {

	public static void main(String[] args) {
		static int 
		JFrame f= new JFrame();
		String[] test = {"m1.PNG","m2.PNG","m3.PNG","m4.PNG","m5.PNG"};
		f.setTitle("실행결과");
		f.setSize(300, 400);
		f.getContentPane().setLayout(null);
		
		//이미지
		JButton img = new JButton();
		
		FlowLayout flow = new FlowLayout();
		f.getContentPane().setLayout(flow);
		JButton pic= new JButton();
		
		
		JButton b1 = new JButton("왼쪽으로");
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				i= i-1;
				if (i==-1)
				
			}
		});
		b1.setBackground(SystemColor.activeCaption);
		b1.setFont(new Font("굴림", Font.PLAIN, 16));
		f.getContentPane().add(b1);
		
		JButton b2 = new JButton("오른쪽으로");
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		b2.setBackground(SystemColor.activeCaption);
		b2.setForeground(Color.BLACK);
		b2.setFont(new Font("굴림", Font.PLAIN, 16));
		f.getContentPane().add(b2);

	}

}
