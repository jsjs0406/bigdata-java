package java09;

import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class 영화정보시스템2 {

	public static void main(String[] args) {
		String[] movies = { "m1.PNG", "m2.PNG", "m3.PNG", "m4.PNG", "m5.PNG" };

		JFrame f = new JFrame();
		f.setTitle("나의 영화 정보시스템");
		f.setSize(300, 450);
		// 물 흐르듯이 하나씩 순서대로 붙여주는 클래스
		FlowLayout flow = new FlowLayout();
		f.getContentPane().setLayout(flow);
		JButton img = new JButton();
		f.getContentPane().add(img);

		JButton b1 = new JButton("<<<이전>>>");
		b1.addActionListener(new ActionListener()/*액션 리스너가 인터페에스, 익명 클래스, 별도의 클래스, 인터페이스는 객체를 형성 할 수 없음 */{
			public void actionPerformed(ActionEvent e) {
				if (status - 1 >= 0) {
					ImageIcon icon = new ImageIcon(movies[status - 1]);
					img.setIcon(icon);
					status = status - 1;
				} else {
					JOptionPane.showMessageDialog(null, "왼쪽이 마지막 입니다. 다음 버튼을 클릭해주세요.");

				}
			}
		});
		f.getContentPane().add(b1);

		JButton b2 = new JButton("<<<이후>>>");
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		f.getContentPane().add(b2);

		ImageIcon icon = new ImageIcon("m3.PNG");

	}

}
