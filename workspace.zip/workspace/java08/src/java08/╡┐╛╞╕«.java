package java08;

import java.util.Scanner;

public class 동아리 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String name[] = {"김아무개", "박아무개", "송아무개", "정아무개", "장아무개"};
		int num[] = {1,2,3,1,1};
		char[] grade = {'A','B','C','A','B'};
		System.out.println("동아리 명단의 이번학기 성적은?");
		System.out.println();
		System.out.println("이름        학년       학점");
		System.out.println("-----------------------------------------------");
		for (int i = 0; i <name.length; i++) {
			System.out.println(name[i] +"     " +num[i]+"      "+grade[i]+"    ");
		}
		int[] num1 = new int[4];
		for (int i = 0; i < num.length; i++) {
			if (num[i] ==1) {
				num1[0]++; 
			}else if (num[i] == 2) {
				num1[1]++;
			}else if (num[i] == 3) {
				num1[2]++;
			}
			else if (num[i] == 4) {
				num1[3]++;
			}
		
		}
		for (int j = 0; j < num1.length; j++) {
			System.out.println(j+1 + "학년:" + num1[j]+"명");
		}
		int[] grade1 = new int[4];
		for (int i = 0; i < grade.length; i++) {
			if (grade[i] =='A') {
				grade1[0]++; 
			}else if (grade[i] == 'B') {
				grade1[1]++;
			}else if (grade[i] == 'C') {
				grade1[2]++;
			}
			else if (grade[i] == 'D') {
				grade1[3]++;
			}else if(grade[i]=='F')
				grade1[4]++;
		}
		for (int j = 0; j < grade1.length; j++) {
			System.out.println(j+1 + "학점:" + grade1[j]+"명");
		}
		
		
	}//m

}//c
