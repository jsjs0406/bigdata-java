package java19;

public class PostDTO {
	String title;
	String content;
	String au;
	int pw;
	
	@Override
	public String toString() {
		return "PostDTO [title=" + title + ", content=" + content + ", au=" + au + ", pw=" + pw + "]";
	}
	public PostDTO(String title, String content, String au, int pw) {
	
		this.title = title;
		this.content = content;
		this.au = au;
		this.pw = pw;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getAu() {
		return au;
	}
	public void setAu(String au) {
		this.au = au;
	}
	public int getPw() {
		return pw;
	}
	public void setPw(int pw) {
		this.pw = pw;
	}
	
	

}
