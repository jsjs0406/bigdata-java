package java19;

import java.util.HashMap;

public class MapTest2 {

	public static void main(String[] args) {
		HashMap memberilst = new HashMap();
		Member m1 = new Member("kim",20,'��',"���α�","011");
		Member m2 = new Member("park",25,'��',"���α�","010");
		Member m3 = new Member("lee",30,'��',"������","011");
		memberilst.put("m100",m1);
		memberilst.put("m200",m1);
		memberilst.put("m300",m1);
		System.out.println(memberilst);
		
		
		
		

	}

}
