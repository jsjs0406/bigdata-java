package java07;

public class 문제응용 {

	public static void main(String[] args) {
		int[] num = new int [5];
		
		for (int i = 0; i < num.length; i++) {
			num[i] = i+1;
		
		
		
		System.out.println(num[i]);
	}
		
		
		

	}

}
