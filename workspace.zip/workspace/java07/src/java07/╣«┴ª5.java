package java07;

public class 문제5 {

	public static void main(String[] args) {
		int[]s= {66,77,88,99};
		int max =s[0];//배열의 첫번째 값:66과 계속 비교하도록
		for (int i = 0; i < s.length; i++) {//for문으로 배열반복 설정
			if(max<s[i]) {//꺼내오는 역할
				max=s[i];
			}
		}System.out.println("최대값은"+max);

	}//m

}//c
