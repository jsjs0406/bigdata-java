package java07;

import java.util.Scanner;

public class 문제4 {

	public static void main(String[] args) {
		System.out.println("숫자를 넣으세요");
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		int[] s = {11,22,33,44};
		for (int i = 0; i < s.length; i++) {
					if(num==s[i])/*넘값이 내가 찾고자하는 아이값과 같다면*/ {
						System.out.println(num+ "의 위치는"+(i));
						
					}
		}

	}//m

}//c
