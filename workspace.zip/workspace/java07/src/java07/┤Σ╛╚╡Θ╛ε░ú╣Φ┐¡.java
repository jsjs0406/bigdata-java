package java07;

public class 답안들어간배열 {

	public static void main(String[] args) {
		int[] num = new int [3];
		//배열에 값을 넣어두지 않으면,
		//자동으로 해당하는 타입의 초기값으로 셋팅
		//int -> 0
		
		System.out.println(num[0]);
		

	}

}
