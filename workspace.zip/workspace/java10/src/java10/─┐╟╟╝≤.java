package java10;

public class 커피숍 {

	public static void main(String[] args) {
		계산기 cal = new 계산기();
		
		int sum = cal.add(5000, 4000);//계산기에서 리턴을 해줬기 때문에 +가 와있는 상태
		System.out.println(sum - 1000 +"원만 내세요");
		
		

	}//m

}//c
