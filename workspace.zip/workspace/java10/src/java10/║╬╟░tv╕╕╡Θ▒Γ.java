package java10;

public class 부품tv만들기 {

	//tv==>class
			//-정적특성: 전원버튼유무, 사이즈, 색 ==>멤버변수
	boolean power;
	int size;
	String color;

	//-동적특성: 채널변경하다, 소리를 조절하다, 잭연결하다.==>멤버메소드
	public void changech() {
		System.out.println("채널변경하다");
	}
	public void sound() {
		System.out.println("소리를 조절하다");
	}
	public void connect() {
		System.out.println("잭을 연결하다.");
	}
	
	@Override //
	public String toString() {
		return power + " "+size+" "+color;
	}
	
	

}//c
