package java10;

import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import java.awt.TextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class 문제1 {
	static int sum;
	static int y;
	static String temp1;
	static String temp2;
	private static JTextField text1;
	private static JTextField text2;

	public static void main(String[] args) {
		String[] food = { "m1.jpg", "m2.jpg", "m3.jpg", "m4.jpg" };

		JFrame f = new JFrame();
		f.setTitle("주문하세요");
		f.setSize(800, 800);
		FlowLayout flow = new FlowLayout();
		f.getContentPane().setLayout(flow);
		ImageIcon icon = new ImageIcon(food[0]);
		JButton img = new JButton();
		img.setIcon(icon);

		JButton b1 = new JButton("짬뽕");
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon icon = new ImageIcon(food[1]);
				img.setIcon(icon);
				y++;
				sum = y * 5000;
				temp1 = Integer.toString(y);
				temp2 = Integer.toString(sum);
				System.out.println(temp1);
				text1.setText(temp1);
				text2.setText(temp2);
			}

		});
		b1.setFont(new Font("굴림", Font.BOLD, 12));
		b1.setBackground(Color.ORANGE);
		f.getContentPane().add(b1);

		JButton b2 = new JButton("우동");
		b2.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				ImageIcon icon = new ImageIcon(food[2]);
				y++;
				sum = y * 5000;
				temp1 = Integer.toString(y);
				temp2 = Integer.toString(sum);
				System.out.println(temp1);
				text1.setText(temp1);
				text2.setText(temp2);
			}

		});
		b2.setFont(new Font("굴림", Font.BOLD, 12));
		b2.setBackground(Color.ORANGE);
		f.getContentPane().add(b2);

		JButton b3 = new JButton("짜장");
		b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon icon = new ImageIcon(food[3]);
				y++;
				sum = y * 5000;
				temp1 = Integer.toString(y);
				temp2 = Integer.toString(sum);
				System.out.println(temp1);
				text1.setText(temp1);
				text2.setText(temp2);
			}
		});
		b3.setFont(new Font("굴림", Font.BOLD, 12));
		b3.setBackground(Color.ORANGE);
		f.getContentPane().add(b3);

		JLabel l1 = new JLabel("개수");
		l1.setFont(new Font("굴림", Font.BOLD, 12));
		f.getContentPane().add(l1);
		
		text1 = new JTextField();
		f.getContentPane().add(text1);
		text1.setColumns(10);

		JLabel l2 = new JLabel("금액");
		l2.setFont(new Font("굴림", Font.BOLD, 12));
		f.getContentPane().add(l2);
		
		text2 = new JTextField();
		f.getContentPane().add(text2);
		text2.setColumns(10);

		f.getContentPane().add(img);

		f.setVisible(true);

	}
}
