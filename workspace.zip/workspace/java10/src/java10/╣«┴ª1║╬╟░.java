package java10;

public class 문제1부품 {
	public int mul(int x, int y) {
		return x * y;//커피숍으로 오버라이딩 하기 위해
	}

}
