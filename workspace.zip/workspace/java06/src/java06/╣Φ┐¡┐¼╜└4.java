package java06;

public class 배열연습4 {

	public static void main(String[] args) {
		int[] num = {444,666,777};
		//배열에 첫번째 값에 세번째 값을 넣어보세요.
		//첫번째 값을 확인, 세번째 값을 확인.
		num[0] = num[2];
		System.out.println(num[0]);
		System.out.println(num[2]);
		/*System.out.println(number.length);
		number[0] = 55;
		for (int i = 0; i < number.length; i++) {
			System.out.println(number[i]);*/
		

	}//m

}//c
