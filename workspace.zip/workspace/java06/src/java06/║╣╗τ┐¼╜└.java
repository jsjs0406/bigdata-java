package java06;

public class 복사연습 {

	public static void main(String[] args) {
		int num1 = 300;
		int nmu2 = 100;
		//num3에 num1값을 복사해보세요, 확인
		int num3 = num1;
		System.out.println(num3);
		//num2에 넘원 값을 복사헤보세요, 확인
		num2 = num1;
		System.out.println(num1);
		System.out.println(num2);
		
	}

}
