package java06;

public class 배열연습3 {

	public static void main(String[] args) {
		int[] number = {44, 66, 22, 88};
		System.out.println(number.length);
		number[0] = 55;
		for (int i = 0; i < number.length; i++) {
			System.out.println(number[i]);
		}

	}//main

}//class
