package 일기장;

import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.SpringLayout;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;

public class 다이어리 {
	private JTextField text1;
	private JTextField text2;
	public 다이어리() {
		
		JFrame f = new JFrame("일기 쓰는 프레임");
		f.getContentPane().setBackground(Color.GREEN);
		f.setSize(600, 600);
		JLabel l = new JLabel("<<<<일기작성날짜>>>>");
		l.setFont(new Font("굴림", Font.PLAIN, 24));
		FlowLayout flow = new FlowLayout();
		
		f.getContentPane().setLayout(flow);
		f.getContentPane().add(l);
		
		text1 = new JTextField();
		text1.setBackground(Color.YELLOW);
		f.getContentPane().add(text1);
		text1.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("<<<<일기작성제목>>>>");
		lblNewLabel.setFont(new Font("굴림", Font.PLAIN, 24));
		f.getContentPane().add(lblNewLabel);
		
		text2 = new JTextField();
		text2.setBackground(Color.YELLOW);
		f.getContentPane().add(text2);
		text2.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("<<<<<일기작성내용>>>>>");
		lblNewLabel_1.setFont(new Font("굴림", Font.PLAIN, 30));
		f.getContentPane().add(lblNewLabel_1);
		
		JTextArea textArea = new JTextArea();
		textArea.setBackground(Color.YELLOW);
		textArea.setColumns(70);
		textArea.setRows(15);
		f.getContentPane().add(textArea);
		
		JButton btnNewButton = new JButton("파일에 저장하기");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					FileWriter w = new FileWriter(text1.getText() +".txt");
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setForeground(Color.LIGHT_GRAY);
		btnNewButton.setBackground(Color.RED);
		btnNewButton.setFont(new Font("굴림", Font.PLAIN, 35));
		f.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("파일에서 읽어오기");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.setForeground(Color.LIGHT_GRAY);
		btnNewButton_1.setBackground(Color.BLUE);
		btnNewButton_1.setFont(new Font("굴림", Font.PLAIN, 35));
		f.getContentPane().add(btnNewButton_1);
		
		JPanel panel = new JPanel();
		f.getContentPane().add(panel);
		panel.setLayout(new SpringLayout());
		f.setVisible(true);
		
		
	}

}
