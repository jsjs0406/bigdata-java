package 생성자;

public class tour {

	public static void main(String[] args) {
		Car car1 = new Car();
		car1.color = "검정색";
		car1.convertible = true;
		System.out.println(car1);
		car1.change();
		int exspeed = car1.speedUp(100);
		System.out.println(exspeed + "로 속도를 up");
		
		
		
		Car car2 = new Car("빨강", false);
		System.out.println(car2);
		System.out.println();
		
		//Car car1 = new Car();
		//car1.color = "검정색";
		//car1.convertible = true;
		//System.out.println(car1);		
		
		
		
		

	}


}
