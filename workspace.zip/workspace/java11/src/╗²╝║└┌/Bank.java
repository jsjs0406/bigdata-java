package 생성자;

public class Bank {
	String product;
	String name;
	int money;
	

	
	
	public Bank(String product, String name, int money) {
		super();
		this.product = product;
		this.name = name;
		this.money = money;
	}
	public void add(int x, double y) {
		System.out.println(x + y);
	}

	@Override
	public String toString() {
		return "Bank [product=" + product + ", name=" + name + ", money=" + money + "]";
	}

}
