package ����1;

public class GoodBank extends Bank {
	@Override
	public double getInterestRate() {
		double rate = 3.0;
		return rate;
		
	}
	

}
