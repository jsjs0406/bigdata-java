package jdbc;

import javax.swing.JOptionPane;

import collection.MemberDAO;
import collection.MemberDTO;
import project.MemberDao;
import project.MemberDto;

public class Membermain {

	public static void main(String[] args) {
		String id = JOptionPane.showInputDialog("id�Է�:");
		String pw = JOptionPane.showInputDialog("pw�Է�:");
		String name = JOptionPane.showInputDialog("name�Է�:");
		String tel = JOptionPane.showInputDialog("tel�Է�:");
		String addr = JOptionPane.showInputDialog("addr�Է�:");
		
		MemberDao db = new MemberDao();
		MemberDto dto = new MemberDto();
		dto.setId(id);
		dto.setPw(pw);
		dto.setName(name);
		dto.setTel(tel);
		dto.setAddr(addr);
		
		try {
			db.insert(dto);
		} catch (Exception e) {
			e.printStackTrace();
		}
		

	}

}
