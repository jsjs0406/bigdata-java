package project;
import javax.swing.JOptionPane;
import project.MemberDao;

public class ����Է� {

	public static void main(String[] args) {
		String id = JOptionPane.showInputDialog("id�Է�:");
		String pw = JOptionPane.showInputDialog("name�Է�:");
		String name = JOptionPane.showInputDialog("pw�Է�:");
		String tel = JOptionPane.showInputDialog("tel�Է�:");
		String addr = JOptionPane.showInputDialog("addr�Է�:");

		MemberDao db = new MemberDao();
		MemberDto dto = new MemberDto();
		try {
			db.insert(id, pw, name, tel, addr);
		} catch (Exception e) {
			System.out.println("�����߻�!!!�����߻�!!!");
		}

	}

}
