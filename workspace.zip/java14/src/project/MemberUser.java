package project;

import java.util.ArrayList;
import java.util.Scanner;

public class MemberUser {
		Scanner sc = new Scanner(System.in);
		ArrayList memberdtoArrayLis
		
		public MemberDao() {
			MemberUser.add(new MemberDao("yang","1234","JeongeEun","010-1234-134",""))
		}
		
		
		

	

}
