package project;

public class TicketDto {
	String mname;
	String city; 
	String day; 
	String hall; 
	String time; 
	String seat; 
	@Override
	public String toString() {
		return "TicketDto [mname=" + mname + ", city=" + city + ", day=" + day + ", hall=" + hall + ", time=" + time
				+ ", seat=" + seat + ", price=" + price + "]";
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public String getHall() {
		return hall;
	}
	public void setHall(String hall) {
		this.hall = hall;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getSeat() {
		return seat;
	}
	public void setSeat(String seat) {
		this.seat = seat;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	String price;

}
